package rs.etf.sab.tests;

import org.junit.Test;
import org.junit.After;
import org.junit.Before;
import org.junit.Assert;
import java.util.HashMap;
import java.math.BigDecimal;
import java.math.RoundingMode;
import javafx.util.Pair;
import java.util.Map;
import rs.etf.sab.operations.DriveOperation;
import rs.etf.sab.operations.PackageOperations;
import rs.etf.sab.operations.StockroomOperations;
import rs.etf.sab.operations.CourierOperations;
import rs.etf.sab.operations.VehicleOperations;
import rs.etf.sab.operations.CourierRequestOperation;
import rs.etf.sab.operations.UserOperations;
import rs.etf.sab.operations.AddressOperations;
import rs.etf.sab.operations.CityOperations;
import rs.etf.sab.operations.GeneralOperations;

public class PublicTest
{
    private GeneralOperations generalOperations;
    private CityOperations cityOperations;
    private AddressOperations addressOperations;
    private UserOperations userOperations;
    private CourierRequestOperation courierRequestOperation;
    private VehicleOperations vehicleOperations;
    private CourierOperations courierOperation;
    private StockroomOperations stockroomOperations;
    private PackageOperations packageOperations;
    private DriveOperation driveOperation;
    private TestHandler testHandler;
    Map<Integer, Pair<Integer, Integer>> addressesCoords;
    Map<Integer, BigDecimal> packagePrice;
    
    public PublicTest() {
        this.addressesCoords = new HashMap<Integer, Pair<Integer, Integer>>();
        this.packagePrice = new HashMap<Integer, BigDecimal>();
    }
    
    @Before
    public void setUp() {
        Assert.assertNotNull(this.testHandler = TestHandler.getInstance());
        Assert.assertNotNull(this.cityOperations = this.testHandler.getCityOperations());
        Assert.assertNotNull(this.addressOperations = this.testHandler.getAddressOperations());
        Assert.assertNotNull(this.userOperations = this.testHandler.getUserOperations());
        Assert.assertNotNull(this.courierRequestOperation = this.testHandler.getCourierRequestOperation());
        Assert.assertNotNull(this.courierOperation = this.testHandler.getCourierOperations());
        Assert.assertNotNull(this.vehicleOperations = this.testHandler.getVehicleOperations());
        Assert.assertNotNull(this.stockroomOperations = this.testHandler.getStockroomOperations());
        Assert.assertNotNull(this.packageOperations = this.testHandler.getPackageOperations());
        Assert.assertNotNull(this.driveOperation = this.testHandler.getDriveOperation());
        Assert.assertNotNull(this.generalOperations = this.testHandler.getGeneralOperations());
        this.generalOperations.eraseAll();
    }
    
    @After
    public void tearUp() {
        this.testHandler.getGeneralOperations().eraseAll();
    }
    
    int insertCity(final String name, final String postalCode) {
        final int idCity = this.cityOperations.insertCity(name, postalCode);
        Assert.assertNotEquals(-1L, idCity);
        Assert.assertTrue(this.cityOperations.getAllCities().contains(idCity));
        return idCity;
    }
    
    int insertAddress(final String street, final int number, final int idCity, final int x, final int y) {
        final int idAddress = this.addressOperations.insertAddress(street, number, idCity, x, y);
        Assert.assertNotEquals(-1L, idAddress);
        Assert.assertTrue(this.addressOperations.getAllAddresses().contains(idAddress));
        this.addressesCoords.put(idAddress, (Pair<Integer, Integer>)new Pair((Object)x, (Object)y));
        return idAddress;
    }
    
    String insertUser(final String username, final String firstName, final String lastName, final String password, final int idAddress) {
        Assert.assertTrue(this.userOperations.insertUser(username, firstName, lastName, password, idAddress));
        Assert.assertTrue(this.userOperations.getAllUsers().contains(username));
        return username;
    }
    
    String insertCourier(final String username, final String firstName, final String lastName, final String password, final int idAddress, final String driverLicenceNumber) {
        this.insertUser(username, firstName, lastName, password, idAddress);
        Assert.assertTrue(this.courierOperation.insertCourier(username, driverLicenceNumber));
        return username;
    }
    
    public void insertAndParkVehicle(final String licencePlateNumber, final BigDecimal fuelConsumption, final BigDecimal capacity, final int fuelType, final int idStockroom) {
        Assert.assertTrue(this.vehicleOperations.insertVehicle(licencePlateNumber, fuelType, fuelConsumption, capacity));
        Assert.assertTrue(this.vehicleOperations.getAllVehichles().contains(licencePlateNumber));
        Assert.assertTrue(this.vehicleOperations.parkVehicle(licencePlateNumber, idStockroom));
    }
    
    public int insertStockroom(final int idAddress) {
        final int stockroomId = this.stockroomOperations.insertStockroom(idAddress);
        Assert.assertNotEquals(-1L, stockroomId);
        Assert.assertTrue(this.stockroomOperations.getAllStockrooms().contains(stockroomId));
        return stockroomId;
    }
    
    int insertAndAcceptPackage(final int addressFrom, final int addressTo, final String userName, final int packageType, final BigDecimal weight) {
        final int idPackage = this.packageOperations.insertPackage(addressFrom, addressTo, userName, packageType, weight);
        Assert.assertNotEquals(-1L, idPackage);
        Assert.assertTrue(this.packageOperations.acceptAnOffer(idPackage));
        Assert.assertTrue(this.packageOperations.getAllPackages().contains(idPackage));
        Assert.assertEquals(1L, this.packageOperations.getDeliveryStatus(idPackage));
        final BigDecimal price = Util.getPackagePrice(packageType, weight, Util.getDistance(this.addressesCoords.get(addressFrom), this.addressesCoords.get(addressTo)));
        Assert.assertTrue(this.packageOperations.getPriceOfDelivery(idPackage).compareTo(price.multiply(new BigDecimal(1.05))) < 0);
        Assert.assertTrue(this.packageOperations.getPriceOfDelivery(idPackage).compareTo(price.multiply(new BigDecimal(0.95))) > 0);
        this.packagePrice.put(idPackage, price);
        System.out.println("cena " + price);
        return idPackage;
    }
    
    @Test
    public void publicOne() {
        final int BG = this.insertCity("Belgrade", "11000");
        final int KG = this.insertCity("Kragujevac", "550000");
        final int VA = this.insertCity("Valjevo", "14000");
        final int CA = this.insertCity("Cacak", "32000");
        final int idAddressBG1 = this.insertAddress("Kraljice Natalije", 37, BG, 11, 15);
        final int idAddressBG2 = this.insertAddress("Bulevar kralja Aleksandra", 73, BG, 10, 10);
        final int idAddressBG3 = this.insertAddress("Vojvode Stepe", 39, BG, 1, -1);
        final int idAddressBG4 = this.insertAddress("Takovska", 7, BG, 11, 12);
        final int idAddressBG5 = this.insertAddress("Bulevar kralja Aleksandra", 37, BG, 12, 12);
        final int idAddressKG1 = this.insertAddress("Daniciceva", 1, KG, 4, 310);
        final int idAddressKG2 = this.insertAddress("Dure Pucara Starog", 2, KG, 11, 320);
        final int idAddressVA1 = this.insertAddress("Cika Ljubina", 8, VA, 102, 101);
        final int idAddressVA2 = this.insertAddress("Karadjordjeva", 122, VA, 104, 103);
        final int idAddressVA3 = this.insertAddress("Milovana Glisica", 45, VA, 101, 101);
        final int idAddressCA1 = this.insertAddress("Zupana Stracimira", 1, CA, 110, 309);
        final int idAddressCA2 = this.insertAddress("Bulevar Vuka Karadzica", 1, CA, 111, 315);
        final int idStockroomBG = this.insertStockroom(idAddressBG1);
        final int idStockroomVA = this.insertStockroom(idAddressVA1);
        this.insertAndParkVehicle("BG1675DA", new BigDecimal(6.3), new BigDecimal(1000.5), 2, idStockroomBG);
        this.insertAndParkVehicle("VA1675DA", new BigDecimal(7.3), new BigDecimal(500.5), 1, idStockroomVA);
        final String username = "crno.dete";
        this.insertUser(username, "Svetislav", "Kisprdilov", "Test_123", idAddressBG1);
        final String courierUsernameBG = "postarBG";
        this.insertCourier(courierUsernameBG, "Pera", "Peric", "Postar_73", idAddressBG2, "654321");
        final String courierUsernameVA = "postarVA";
        this.insertCourier(courierUsernameVA, "Pera", "Peric", "Postar_73", idAddressBG2, "123456");
        final int type1 = 0;
        final BigDecimal weight1 = new BigDecimal(2);
        final int idPackage1 = this.insertAndAcceptPackage(idAddressBG2, idAddressCA1, username, type1, weight1);
        final int type2 = 1;
        final BigDecimal weight2 = new BigDecimal(4);
        final int idPackage2 = this.insertAndAcceptPackage(idAddressBG3, idAddressVA1, username, type2, weight2);
        final int type3 = 2;
        final BigDecimal weight3 = new BigDecimal(5);
        final int idPackage3 = this.insertAndAcceptPackage(idAddressBG4, idAddressKG1, username, type3, weight3);
        Assert.assertEquals(0L, this.courierOperation.getCouriersWithStatus(1).size());
        this.driveOperation.planingDrive(courierUsernameBG); 
     //   return;
        Assert.assertTrue(this.courierOperation.getCouriersWithStatus(1).contains(courierUsernameBG));
        final int type4 = 3;
        final BigDecimal weight4 = new BigDecimal(2);
        final int idPackage4 = this.insertAndAcceptPackage(idAddressBG2, idAddressKG2, username, type4, weight4);
        Assert.assertEquals(4L, this.packageOperations.getAllPackagesCurrentlyAtCity(BG).size());
        
     //  return;
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage1));
        Assert.assertEquals(1L, this.packageOperations.getDeliveryStatus(idPackage2));
        Assert.assertEquals(1L, this.packageOperations.getDeliveryStatus(idPackage3));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage1));
        Assert.assertNotEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage2));
        Assert.assertNotEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage3));
        Assert.assertEquals(3L, this.packageOperations.getAllPackagesCurrentlyAtCity(BG).size());
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage1));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage2));
        Assert.assertEquals(1L, this.packageOperations.getDeliveryStatus(idPackage3));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage1));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage2));
        Assert.assertNotEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage3));
        Assert.assertEquals(2L, this.packageOperations.getAllPackagesCurrentlyAtCity(BG).size());
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage1));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage2));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage3));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage1));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage2));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage3));
        Assert.assertEquals(1L, this.packageOperations.getAllPackagesCurrentlyAtCity(BG).size());
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        
        
        Assert.assertEquals(idPackage2, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage1));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(idPackage2));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage3));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage1));
        Assert.assertNotEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage2));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage3));
        Assert.assertEquals(1L, this.packageOperations.getAllPackagesCurrentlyAtCity(VA).size());
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
      
        Assert.assertEquals(idPackage1, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(idPackage1));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(idPackage2));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage3));
        Assert.assertNotEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage1));
        Assert.assertNotEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage2));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage3));
        Assert.assertEquals(1L, this.packageOperations.getAllPackagesCurrentlyAtCity(CA).size());
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        

        Assert.assertEquals(idPackage3, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(idPackage1));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(idPackage2));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(idPackage3));
        Assert.assertNotEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage1));
        Assert.assertNotEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage2));
        Assert.assertNotEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(idPackage3));
        Assert.assertEquals(1L, this.packageOperations.getAllPackagesCurrentlyAtCity(KG).size());
        Assert.assertEquals(0L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        //return;
        Assert.assertEquals(-1L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(1L, this.packageOperations.getDeliveryStatus(idPackage4));
        Assert.assertEquals(1L, this.packageOperations.getAllUndeliveredPackages().size());
        Assert.assertTrue(this.packageOperations.getAllUndeliveredPackages().contains(idPackage4));
        Assert.assertEquals(2L, this.courierOperation.getCouriersWithStatus(0).size());
        final double distance = Util.getDistance(this.addressesCoords.get(idAddressBG1), this.addressesCoords.get(idAddressBG2), this.addressesCoords.get(idAddressBG3), this.addressesCoords.get(idAddressBG4), this.addressesCoords.get(idAddressVA1), this.addressesCoords.get(idAddressCA1), this.addressesCoords.get(idAddressKG1), this.addressesCoords.get(idAddressBG1));
        BigDecimal profit = this.packagePrice.get(idPackage1).add(this.packagePrice.get(idPackage2)).add(this.packagePrice.get(idPackage3));
        profit = profit.subtract(new BigDecimal(36).multiply(new BigDecimal(6.3)).multiply(new BigDecimal(distance)));
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(3).compareTo(profit.multiply(new BigDecimal(1.05))) < 0);
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(3).compareTo(profit.multiply(new BigDecimal(0.95))) > 0);
    }
    
    @Test
    public void publicTwo() {
        final int BG = this.insertCity("Belgrade", "11000");
        final int KG = this.insertCity("Kragujevac", "550000");
        final int VA = this.insertCity("Valjevo", "14000");
        final int CA = this.insertCity("Cacak", "32000");
        final int idAddressBG1 = this.insertAddress("Kraljice Natalije", 37, BG, 11, 15);
        final int idAddressBG2 = this.insertAddress("Bulevar kralja Aleksandra", 73, BG, 10, 10);
        final int idAddressBG3 = this.insertAddress("Vojvode Stepe", 39, BG, 1, -1);
        final int idAddressBG4 = this.insertAddress("Takovska", 7, BG, 11, 12);
        final int idAddressBG5 = this.insertAddress("Bulevar kralja Aleksandra", 37, BG, 12, 12);
        final int idAddressKG1 = this.insertAddress("Daniciceva", 1, KG, 4, 310);
        final int idAddressKG2 = this.insertAddress("Dure Pucara Starog", 2, KG, 11, 320);
        final int idAddressVA1 = this.insertAddress("Cika Ljubina", 8, VA, 102, 101);
        final int idAddressVA2 = this.insertAddress("Karadjordjeva", 122, VA, 104, 103);
        final int idAddressVA3 = this.insertAddress("Milovana Glisica", 45, VA, 101, 101);
        final int idAddressCA1 = this.insertAddress("Zupana Stracimira", 1, CA, 110, 309);
        final int idAddressCA2 = this.insertAddress("Bulevar Vuka Karadzica", 1, CA, 111, 315);
        final int idStockroomBG = this.insertStockroom(idAddressBG1);
        final int idStockroomVA = this.insertStockroom(idAddressVA1);
        this.insertAndParkVehicle("BG1675DA", new BigDecimal(6.3), new BigDecimal(1000.5), 2, idStockroomBG);
        this.insertAndParkVehicle("VA1675DA", new BigDecimal(7.3), new BigDecimal(500.5), 1, idStockroomVA);
        final String username = "crno.dete";
        this.insertUser(username, "Svetislav", "Kisprdilov", "Test_123", idAddressBG1);
        final String courierUsernameBG = "postarBG";
        this.insertCourier(courierUsernameBG, "Pera", "Peric", "Postar_73", idAddressBG2, "654321");
        final String courierUsernameVA = "postarVA";
        this.insertCourier(courierUsernameVA, "Pera", "Peric", "Postar_73", idAddressVA2, "123456");
        final int type = 1;
        final BigDecimal weight = new BigDecimal(4);
        final int idPackage1 = this.insertAndAcceptPackage(idAddressBG2, idAddressKG1, username, type, weight);
        final int idPackage2 = this.insertAndAcceptPackage(idAddressKG2, idAddressBG4, username, type, weight);
        final int idPackage3 = this.insertAndAcceptPackage(idAddressVA2, idAddressCA1, username, type, weight);
        final int idPackage4 = this.insertAndAcceptPackage(idAddressCA2, idAddressBG4, username, type, weight);
        Assert.assertEquals(0L, this.courierOperation.getCouriersWithStatus(1).size());
        this.driveOperation.planingDrive(courierUsernameBG);
        this.driveOperation.planingDrive(courierUsernameVA);
        
        Assert.assertEquals(2L, this.courierOperation.getCouriersWithStatus(1).size());
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(idPackage1, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(idPackage1));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameVA));
        Assert.assertEquals(idPackage3, this.driveOperation.nextStop(courierUsernameVA));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(idPackage3));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage2));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameVA));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage4));
        Assert.assertEquals(-1L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage2));
        Assert.assertTrue(this.packageOperations.getAllPackagesCurrentlyAtCity(BG).contains(idPackage2));
        Assert.assertTrue(this.packageOperations.getAllPackagesCurrentlyAtCity(KG).contains(idPackage1));
        Assert.assertEquals(-1L, this.driveOperation.nextStop(courierUsernameVA));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage4));
        Assert.assertTrue(this.packageOperations.getAllPackagesCurrentlyAtCity(VA).contains(idPackage4));
        Assert.assertTrue(this.packageOperations.getAllPackagesCurrentlyAtCity(CA).contains(idPackage3));
        final int idPackage5 = this.insertAndAcceptPackage(idAddressVA2, idAddressCA1, username, type, weight);
        final int idPackage6 = this.insertAndAcceptPackage(idAddressBG3, idAddressVA3, username, type, weight);
      
        //return;
        this.driveOperation.planingDrive(courierUsernameBG);
        
        //return;
        //pokupi P6 sa adrese
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage6));
        Assert.assertTrue(this.packageOperations.getAllPackagesCurrentlyAtCity(BG).contains(idPackage2));
        Assert.assertFalse(this.packageOperations.getAllPackagesCurrentlyAtCity(BG).contains(idPackage6));
        //pokupi P2 iz magacina
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(idPackage2));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(idPackage6));
        //isporuci P2
        Assert.assertEquals(idPackage2, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(idPackage2));
        //isporuci P6
        Assert.assertEquals(idPackage6, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(idPackage6));
        Assert.assertEquals(0L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        //pokupi P5 iz VA sa adrese
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage5));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(idPackage5));
        //pokupi P4 iz magacina VA !!!!!!!!!!!!!!!!!!!!!!
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(idPackage4));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(idPackage4));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(idPackage5));
        Assert.assertEquals(1L, this.packageOperations.getAllPackagesCurrentlyAtCity(VA).size());
        Assert.assertTrue(this.packageOperations.getAllPackagesCurrentlyAtCity(VA).contains(idPackage6));
        Assert.assertEquals(-1L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(0L, this.packageOperations.getAllUndeliveredPackagesFromCity(BG).size());
        Assert.assertEquals(3L, this.packageOperations.getAllPackagesCurrentlyAtCity(BG).size());
        Assert.assertTrue(this.packageOperations.getAllPackagesCurrentlyAtCity(BG).contains(idPackage2));
        Assert.assertTrue(this.packageOperations.getAllPackagesCurrentlyAtCity(BG).contains(idPackage4));
        Assert.assertTrue(this.packageOperations.getAllPackagesCurrentlyAtCity(BG).contains(idPackage5));
        
        this.driveOperation.planingDrive(courierUsernameBG);
        Assert.assertEquals(0L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(idPackage4));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(idPackage5));
        Assert.assertEquals(idPackage4, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(idPackage4));
        Assert.assertEquals(idPackage5, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(idPackage5));
        Assert.assertEquals(-1L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(0L, this.packageOperations.getAllUndeliveredPackages().size());
        Assert.assertEquals(2L, this.courierOperation.getCouriersWithStatus(0).size());
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(1).compareTo(new BigDecimal(0)) > 0);
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(5).compareTo(new BigDecimal(0)) > 0);
    }
    
    @Test
    public void myPublicTest() {
        final int BG = this.insertCity("Beograd", "11111");
        final int NS = this.insertCity("Novi Sad", "22222");
        final int SU = this.insertCity("Subotica", "33333");
        final int KG = this.insertCity("Kragujevac", "44444");
        
        final int idAddressBG1 = this.insertAddress("Beograd ulica", 1, BG, 70, 120);
        final int idAddressBG2 = this.insertAddress("Beograd ulica", 2, BG, 80, 120);
        final int idAddressBG3 = this.insertAddress("Beograd ulica", 3, BG, 90, 130);
        final int idAddressBG4 = this.insertAddress("Beograd ulica", 4, BG, 90, 110);
        final int idAddressBG5 = this.insertAddress("Beograd ulica", 5, BG, 100, 120);
        
        final int idAddressNS1 = this.insertAddress("Novi Sad ulica", 1, NS, 20, 160);
        final int idAddressNS2 = this.insertAddress("Novi Sad ulica", 2, NS, 40, 160);
        final int idAddressNS3 = this.insertAddress("Novi Sad ulica", 3, NS, 20, 150);
        
        final int idAddressSU1 = this.insertAddress("Subotica ulica", 1, SU, 60, 220);
        final int idAddressSU2 = this.insertAddress("Subotica ulica", 2, SU, 70, 230);
        final int idAddressSU3 = this.insertAddress("Subotica ulica", 3, SU, 70, 210);
        
        
        final int idAddressKG1 = this.insertAddress("Kragujevac ulica", 1, KG, 100, 40);
        final int idAddressKG2 = this.insertAddress("Kragujevac ulica", 2, KG, 110, 40);
        final int idAddressKG3 = this.insertAddress("Kragujevac ulica", 3, KG, 110, 30);
        final int idAddressKG4 = this.insertAddress("Kragujevac ulica", 4, KG, 120, 30);
        
        
        final int idStockroomBG = this.insertStockroom(idAddressBG1);
        final int idStockroomNS = this.insertStockroom(idAddressNS1);
        final int idStockroomSU = this.insertStockroom(idAddressSU1);
        final int idStockroomKG = this.insertStockroom(idAddressKG1);
        
        
        this.insertAndParkVehicle("BG1675DA", new BigDecimal(6.3), new BigDecimal(300), 2, idStockroomBG);
        this.insertAndParkVehicle("KG1675DA", new BigDecimal(7.3), new BigDecimal(500), 1, idStockroomKG);
        this.insertAndParkVehicle("NS1675DA", new BigDecimal(6.3), new BigDecimal(750), 2, idStockroomNS);
        this.insertAndParkVehicle("SU1675DA", new BigDecimal(7.3), new BigDecimal(300), 1, idStockroomSU);
        
        
        final String username = "crno.dete";
        this.insertUser(username, "Svetislav", "Kisprdilov", "Test_123", idAddressBG1);
        
        final String courierUsernameBG = "kurirBG";
        this.insertCourier(courierUsernameBG, "Pera", "Peric", "Postar_73", idAddressBG2, "654321");
        
        final String courierUsernameNS = "kurirNS";
        this.insertCourier(courierUsernameNS, "Pera", "Peric", "Postar_73", idAddressNS2, "123456");
        
        final String courierUsernameSU = "kurirSU";
        this.insertCourier(courierUsernameSU, "Pera", "Peric", "Postar_73", idAddressSU2, "566552");
        
        final String courierUsernameKG = "postarKG";
        this.insertCourier(courierUsernameKG, "Pera", "Peric", "Postar_73", idAddressKG2, "549847");
        
        final int small = 0;
        final int standard = 1;
        final int non_standard = 2;
        final int fragile = 3;
        
        final BigDecimal weight = new BigDecimal(30);
        
        final int pack1_BG_BG = this.insertAndAcceptPackage(idAddressBG5, idAddressBG2, username, small, weight);
        final int pack2_BG_NS = this.insertAndAcceptPackage(idAddressBG2, idAddressNS2, username, fragile, weight);
        final int pack3_BG_NS = this.insertAndAcceptPackage(idAddressBG3, idAddressNS3, username, standard, weight);
        final int pack4_BG_SU = this.insertAndAcceptPackage(idAddressBG4, idAddressSU3, username, non_standard, weight);
        final int pack5_BG_SU = this.insertAndAcceptPackage(idAddressBG5, idAddressSU2, username, standard, weight);
        final int pack6_BG_KG = this.insertAndAcceptPackage(idAddressBG4, idAddressKG2, username, non_standard, BigDecimal.valueOf(200));
        
        final int pack1_NS_KG = this.insertAndAcceptPackage(idAddressNS3, idAddressKG3, username, standard, BigDecimal.valueOf(60));
        final int pack2_NS_SU = this.insertAndAcceptPackage(idAddressNS2, idAddressSU2, username, standard, BigDecimal.valueOf(245));
        
        Assert.assertEquals(4L, this.courierOperation.getCouriersWithStatus(0).size());
        Assert.assertEquals(0L, this.courierOperation.getCouriersWithStatus(1).size());
        
        //kurirBG planira
        this.driveOperation.planingDrive(courierUsernameBG);
        Assert.assertEquals(1L, this.courierOperation.getCouriersWithStatus(1).size());
     
        final int pack3_NS_BG = this.insertAndAcceptPackage(idAddressNS3, idAddressBG5, username, small, BigDecimal.valueOf(4));
        
        final int pack1_SU_KG = this.insertAndAcceptPackage(idAddressSU2, idAddressKG2, username, standard, BigDecimal.valueOf(5));
        final int pack2_SU_BG = this.insertAndAcceptPackage(idAddressSU3, idAddressBG2, username, standard, BigDecimal.valueOf(5));
        
        
        //kurirNS planira
        this.driveOperation.planingDrive(courierUsernameNS);
        Assert.assertEquals(2L, this.courierOperation.getCouriersWithStatus(1).size());
        
        final int pack3_SU_SU = this.insertAndAcceptPackage(idAddressSU2, idAddressSU3, username, standard, BigDecimal.valueOf(50));
        final int pack4_SU_KG = this.insertAndAcceptPackage(idAddressSU3, idAddressKG3, username, standard, BigDecimal.valueOf(60));
        final int pack5_SU_SU = this.insertAndAcceptPackage(idAddressSU3, idAddressSU2, username, standard, BigDecimal.valueOf(2.5));
        
        //kurirKG planira a jos nema paketa za skupljanje u kragujevcu!!!
        this.driveOperation.planingDrive(courierUsernameKG);
        Assert.assertEquals(2L, this.courierOperation.getCouriersWithStatus(1).size());
        
        //kurirSU planira
        this.driveOperation.planingDrive(courierUsernameSU);
        Assert.assertEquals(3L, this.courierOperation.getCouriersWithStatus(1).size());

        
        //kurirBG dohvata prvi paket
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack1_BG_BG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack1_BG_BG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack1_BG_BG));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack1_BG_BG));
        
        
        //kurirNS dohvata prvi paket
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack2_NS_SU));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack2_NS_SU));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack2_NS_SU));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack2_NS_SU));
        
        
        //kurirNS dohvata prvi paket
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack3_NS_BG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack3_NS_BG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack3_NS_BG));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack3_NS_BG));
        
        
        //kurirSU dohvata prvi paket
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack3_SU_SU));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameSU));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack3_SU_SU));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameSU).contains(pack3_SU_SU));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameSU).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack3_SU_SU));
        
        
        //kurirBG kurirBG dohvata drugi paket
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack2_BG_NS));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack2_BG_NS));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack2_BG_NS));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack2_BG_NS));
        
        
        //kurirBG dohvata treci paket
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack3_BG_NS));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack3_BG_NS));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack3_BG_NS));
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack3_BG_NS));
        
        
        //kurirBG dohvata cetvrti paket
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack4_BG_SU));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack4_BG_SU));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack4_BG_SU));
        Assert.assertEquals(4L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack4_BG_SU));
        
        
        //kurirSU dohvata drugi paket
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack4_SU_KG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameSU));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack4_SU_KG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameSU).contains(pack4_SU_KG));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameSU).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack4_SU_KG));
        
        
        
        //kurirNS isporucuje prvi paket u bg
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack3_NS_BG));
        Assert.assertEquals(pack3_NS_BG, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack3_NS_BG));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack3_NS_BG));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack3_NS_BG));
        
        
        //kurirNS dohvata paket iz bg za magacin
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack6_BG_KG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack6_BG_KG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack6_BG_KG));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack6_BG_KG));
        
        
        //kurirBG dohvata peti paket
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack5_BG_SU));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack5_BG_SU));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack5_BG_SU));
        Assert.assertEquals(5L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack5_BG_SU));
        
        
        //kurirBG isporucuje prvi paket u bg
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack1_BG_BG));
        Assert.assertEquals(pack1_BG_BG, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack1_BG_BG));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack1_BG_BG));
        Assert.assertEquals(4L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack1_BG_BG));
        
        
        //kurirNS isporucuje drugi paket u su
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack2_NS_SU));
        Assert.assertEquals(pack2_NS_SU, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack2_NS_SU));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack2_NS_SU));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack2_NS_SU));
        
        
        //kurirNS dohvata prvi paket iz su za magacin
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack1_SU_KG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack1_SU_KG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack1_SU_KG));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack1_SU_KG));
        
        
        //kurirSU dohvata treci paket
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack5_SU_SU));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameSU));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack5_SU_SU));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameSU).contains(pack5_SU_SU));
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameSU).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack5_SU_SU));
        
        
        //kurirNS dohvata drugi paket iz su za magacin
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack2_SU_BG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack2_SU_BG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack2_SU_BG));
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack2_SU_BG));
        
        
        //kurirBG isporucuje drugi paket u ns
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack2_BG_NS));
        Assert.assertEquals(pack2_BG_NS, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack2_BG_NS));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack2_BG_NS));
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack2_BG_NS));
        
        
        //kurirBG isporucuje treci paket u ns
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack3_BG_NS));
        Assert.assertEquals(pack3_BG_NS, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack3_BG_NS));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack3_BG_NS));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack3_BG_NS));
        
        
        //kurirSU isporucuje prvi paket u su
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack3_SU_SU));
        Assert.assertEquals(pack3_SU_SU, this.driveOperation.nextStop(courierUsernameSU));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack3_SU_SU));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameSU).contains(pack3_SU_SU));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameSU).size());
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack3_SU_SU));
        
        
        //kurirBG dohvata novi paket iz ns
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack1_NS_KG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack1_NS_KG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack1_NS_KG));
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack1_NS_KG));
        
        
        //kurirNS se vraca u magacin
        Assert.assertEquals(-1L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(2L, this.courierOperation.getCouriersWithStatus(1).size());
        Assert.assertEquals(0L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack6_BG_KG));
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack1_SU_KG));
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack2_SU_BG));
        Assert.assertTrue(this.courierOperation.getCouriersWithStatus(0).contains(courierUsernameNS));
        BigDecimal profitNS1 = BigDecimal.valueOf(1889017).subtract(BigDecimal.valueOf(361.69).multiply(BigDecimal.valueOf(6.3).multiply(BigDecimal.valueOf(36))));
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(2).compareTo(profitNS1.multiply(BigDecimal.valueOf(1.05))) < 0);
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(2).compareTo(profitNS1.multiply(BigDecimal.valueOf(0.95))) > 0);
        
        
        //kurirSU isporucuje drugi paket u su
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack5_SU_SU));
        Assert.assertEquals(pack5_SU_SU, this.driveOperation.nextStop(courierUsernameSU));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack5_SU_SU));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameSU).contains(pack5_SU_SU));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameSU).size());
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack5_SU_SU));
        
        
        //kurirBG isporucuje cetvrti paket u su
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack4_BG_SU));
        Assert.assertEquals(pack4_BG_SU, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack4_BG_SU));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack4_BG_SU));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack4_BG_SU));
        
        
        //kurirSU isporucuje treci paket u kg
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack4_SU_KG));
        Assert.assertEquals(pack4_SU_KG, this.driveOperation.nextStop(courierUsernameSU));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack4_SU_KG));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameSU).contains(pack4_SU_KG));
        Assert.assertEquals(0L, this.driveOperation.getPackagesInVehicle(courierUsernameSU).size());
        Assert.assertEquals(KG, this.packageOperations.getCurrentLocationOfPackage(pack4_SU_KG));
        
                
        //kurirBG isporucuje peti paket u su
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack5_BG_SU));
        Assert.assertEquals(pack5_BG_SU, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack5_BG_SU));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack5_BG_SU));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack5_BG_SU));
        
        
        //kurirBG se vraca u magacin
        Assert.assertEquals(-1L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(1L, this.courierOperation.getCouriersWithStatus(1).size());
        Assert.assertEquals(0L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack1_NS_KG));
        Assert.assertTrue(this.courierOperation.getCouriersWithStatus(0).contains(courierUsernameBG));
        BigDecimal profitBG1 = BigDecimal.valueOf(1795211).subtract(BigDecimal.valueOf(405.3).multiply(BigDecimal.valueOf(6.3).multiply(BigDecimal.valueOf(36))));
        
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(5).compareTo(profitBG1.multiply(BigDecimal.valueOf(1.05))) < 0);
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(5).compareTo(profitBG1.multiply(BigDecimal.valueOf(0.95))) > 0);
        
        
        //kurirBG planira
        this.driveOperation.planingDrive(courierUsernameNS);
        Assert.assertEquals(2L, this.courierOperation.getCouriersWithStatus(1).size());
     
        
        //kurirSU se vraca u magacin
        Assert.assertEquals(-1L, this.driveOperation.nextStop(courierUsernameSU));
        Assert.assertEquals(1L, this.courierOperation.getCouriersWithStatus(1).size());
        Assert.assertEquals(0L, this.driveOperation.getPackagesInVehicle(courierUsernameSU).size());
        Assert.assertEquals(2L, this.packageOperations.getAllUndeliveredPackagesFromCity(SU).size());
        Assert.assertTrue(this.courierOperation.getCouriersWithStatus(0).contains(courierUsernameSU));
        BigDecimal profitSU1 = BigDecimal.valueOf(1250613).subtract(BigDecimal.valueOf(459.53).multiply(BigDecimal.valueOf(7.3).multiply(BigDecimal.valueOf(32))));
        
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(3).compareTo(profitSU1.multiply(BigDecimal.valueOf(1.05))) < 0);
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(3).compareTo(profitSU1.multiply(BigDecimal.valueOf(0.95))) > 0);
 
        
        //kurirNS dohvata pakete iz magacina
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack6_BG_KG));
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack1_SU_KG));
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack2_SU_BG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack6_BG_KG));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack1_SU_KG));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack2_SU_BG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack6_BG_KG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack1_SU_KG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack2_SU_BG));
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        
        
        //kurirNS isporucuje prvi paket u bg
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack2_SU_BG));
        Assert.assertEquals(pack2_SU_BG, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack2_SU_BG));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack2_SU_BG));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack2_SU_BG));
        
        
        //kurirNS dohvata pakete iz magacina u bg
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack1_NS_KG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack1_NS_KG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack1_NS_KG));
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(-1, this.packageOperations.getCurrentLocationOfPackage(pack1_NS_KG));
        
        
        //kurirNS isporucuje drugi i treci paket u kg
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack1_SU_KG));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack6_BG_KG));
        int firstDeliveredPack = this.driveOperation.nextStop(courierUsernameNS);
        Assert.assertTrue((firstDeliveredPack == pack1_SU_KG) || (firstDeliveredPack == pack6_BG_KG));
        int secondDeliveredPack = this.driveOperation.nextStop(courierUsernameNS);
        Assert.assertTrue((secondDeliveredPack == pack1_SU_KG) || (secondDeliveredPack == pack6_BG_KG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack1_SU_KG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack6_BG_KG));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack1_SU_KG));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack6_BG_KG));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(KG, this.packageOperations.getCurrentLocationOfPackage(pack1_SU_KG));
        Assert.assertEquals(KG, this.packageOperations.getCurrentLocationOfPackage(pack6_BG_KG));
        
        
        //kurirNS se vraca u magacin
        Assert.assertEquals(-1L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(0L, this.courierOperation.getCouriersWithStatus(1).size());
        Assert.assertEquals(0L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(1L, this.packageOperations.getAllUndeliveredPackagesFromCity(NS).size());
        Assert.assertEquals(0L, this.packageOperations.getAllUndeliveredPackagesFromCity(BG).size());
        Assert.assertEquals(0L, this.packageOperations.getAllUndeliveredPackagesFromCity(SU).size());
        Assert.assertEquals(0L, this.packageOperations.getAllUndeliveredPackagesFromCity(KG).size());
        Assert.assertTrue(this.courierOperation.getCouriersWithStatus(0).contains(courierUsernameNS));
        BigDecimal profitNS2 = BigDecimal.valueOf(1666406).subtract(BigDecimal.valueOf(325.11).multiply(BigDecimal.valueOf(6.3).multiply(BigDecimal.valueOf(36))));
        
        BigDecimal avgWithFiveDel = profitNS1.add(profitNS2).add(profitBG1);
        avgWithFiveDel = avgWithFiveDel.divide(BigDecimal.valueOf(3.0), 3, RoundingMode.HALF_DOWN);
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(5).compareTo(avgWithFiveDel.multiply(BigDecimal.valueOf(1.05))) < 0);
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(5).compareTo(avgWithFiveDel.multiply(BigDecimal.valueOf(0.95))) > 0);
        
    }
    
    
    @Test
    public void myPublicTestStrain() {
        final int BG = this.insertCity("Beograd", "11111");
        final int NS = this.insertCity("Novi Sad", "22222");
        final int SU = this.insertCity("Subotica", "33333");
        final int KG = this.insertCity("Kragujevac", "44444");
        
        final int idAddressBG1 = this.insertAddress("Beograd ulica", 1, BG, 70, 120);
        final int idAddressBG2 = this.insertAddress("Beograd ulica", 2, BG, 80, 120);
        final int idAddressBG3 = this.insertAddress("Beograd ulica", 3, BG, 90, 130);
        final int idAddressBG4 = this.insertAddress("Beograd ulica", 4, BG, 90, 110);
        final int idAddressBG5 = this.insertAddress("Beograd ulica", 5, BG, 100, 120);
        
        final int idAddressNS1 = this.insertAddress("Novi Sad ulica", 1, NS, 20, 160);
        final int idAddressNS2 = this.insertAddress("Novi Sad ulica", 2, NS, 40, 160);
        final int idAddressNS3 = this.insertAddress("Novi Sad ulica", 3, NS, 20, 150);
        
        final int idAddressSU1 = this.insertAddress("Subotica ulica", 1, SU, 60, 220);
        final int idAddressSU2 = this.insertAddress("Subotica ulica", 2, SU, 70, 230);
        final int idAddressSU3 = this.insertAddress("Subotica ulica", 3, SU, 70, 210);
        
        
        final int idAddressKG1 = this.insertAddress("Kragujevac ulica", 1, KG, 100, 40);
        final int idAddressKG2 = this.insertAddress("Kragujevac ulica", 2, KG, 110, 40);
        final int idAddressKG3 = this.insertAddress("Kragujevac ulica", 3, KG, 110, 30);
        final int idAddressKG4 = this.insertAddress("Kragujevac ulica", 4, KG, 120, 30);
        
        
        final int idStockroomBG = this.insertStockroom(idAddressBG1);
        final int idStockroomNS = this.insertStockroom(idAddressNS1);
        final int idStockroomSU = this.insertStockroom(idAddressSU1);
        final int idStockroomKG = this.insertStockroom(idAddressKG1);
        
        
        this.insertAndParkVehicle("BG1675DA", new BigDecimal(6.3), new BigDecimal(300), 2, idStockroomBG);
        this.insertAndParkVehicle("KG1675DA", new BigDecimal(7.3), new BigDecimal(500), 1, idStockroomKG);
        this.insertAndParkVehicle("NS1675DA", new BigDecimal(6.3), new BigDecimal(750), 2, idStockroomNS);
        this.insertAndParkVehicle("SU1675DA", new BigDecimal(7.3), new BigDecimal(300), 1, idStockroomSU);
        
        
        final String username = "crno.dete";
        this.insertUser(username, "Svetislav", "Kisprdilov", "Test_123", idAddressBG1);
        
        final String courierUsernameBG = "kurirBG";
        this.insertCourier(courierUsernameBG, "Pera", "Peric", "Postar_73", idAddressBG2, "654321");
        
        final String courierUsernameNS = "kurirNS";
        this.insertCourier(courierUsernameNS, "Pera", "Peric", "Postar_73", idAddressNS2, "123456");
        
        final String courierUsernameSU = "kurirSU";
        this.insertCourier(courierUsernameSU, "Pera", "Peric", "Postar_73", idAddressSU2, "566552");
        
        final String courierUsernameKG = "postarKG";
        this.insertCourier(courierUsernameKG, "Pera", "Peric", "Postar_73", idAddressKG2, "549847");
        
        final int small = 0;
        final int standard = 1;
        final int non_standard = 2;
        final int fragile = 3;
        
        final BigDecimal weight = new BigDecimal(30);
        
        final int pack1_BG_BG = this.insertAndAcceptPackage(idAddressBG5, idAddressBG2, username, small, weight);
        final int pack2_BG_NS = this.insertAndAcceptPackage(idAddressBG2, idAddressNS2, username, fragile, weight);
        final int pack3_BG_NS = this.insertAndAcceptPackage(idAddressBG3, idAddressNS3, username, standard, weight);
        final int pack4_BG_SU = this.insertAndAcceptPackage(idAddressBG4, idAddressSU3, username, non_standard, weight);
        final int pack5_BG_SU = this.insertAndAcceptPackage(idAddressBG5, idAddressSU2, username, standard, weight);
        final int pack6_BG_KG = this.insertAndAcceptPackage(idAddressBG4, idAddressKG2, username, non_standard, BigDecimal.valueOf(200));
        
        final int pack1_NS_KG = this.insertAndAcceptPackage(idAddressNS3, idAddressKG3, username, standard, BigDecimal.valueOf(60));
        final int pack2_NS_SU = this.insertAndAcceptPackage(idAddressNS2, idAddressSU2, username, standard, BigDecimal.valueOf(245));
        
        Assert.assertEquals(4L, this.courierOperation.getCouriersWithStatus(0).size());
        Assert.assertEquals(0L, this.courierOperation.getCouriersWithStatus(1).size());
        
        //kurirBG planira
        this.driveOperation.planingDrive(courierUsernameBG);
        Assert.assertEquals(1L, this.courierOperation.getCouriersWithStatus(1).size());
     
        final int pack3_NS_BG = this.insertAndAcceptPackage(idAddressNS3, idAddressBG5, username, small, BigDecimal.valueOf(4));
        
        final int pack1_SU_KG = this.insertAndAcceptPackage(idAddressSU2, idAddressKG2, username, standard, BigDecimal.valueOf(5));
        final int pack2_SU_BG = this.insertAndAcceptPackage(idAddressSU3, idAddressBG2, username, standard, BigDecimal.valueOf(5));
        
        
        //kurirNS planira
        this.driveOperation.planingDrive(courierUsernameNS);
        Assert.assertEquals(2L, this.courierOperation.getCouriersWithStatus(1).size());
        
        final int pack3_SU_SU = this.insertAndAcceptPackage(idAddressSU2, idAddressSU3, username, standard, BigDecimal.valueOf(50));
        final int pack4_SU_KG = this.insertAndAcceptPackage(idAddressSU3, idAddressKG3, username, standard, BigDecimal.valueOf(60));
        final int pack5_SU_SU = this.insertAndAcceptPackage(idAddressSU3, idAddressSU2, username, standard, BigDecimal.valueOf(2.5));
        
        //kurirKG planira a jos nema paketa za skupljanje u kragujevcu!!!
        this.driveOperation.planingDrive(courierUsernameKG);
        Assert.assertEquals(2L, this.courierOperation.getCouriersWithStatus(1).size());
        
        //kurirSU planira
        this.driveOperation.planingDrive(courierUsernameSU);
        Assert.assertEquals(3L, this.courierOperation.getCouriersWithStatus(1).size());

        
        //kurirBG dohvata prvi paket
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack1_BG_BG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack1_BG_BG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack1_BG_BG));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack1_BG_BG));
        
        
        //kurirNS dohvata prvi paket
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack2_NS_SU));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack2_NS_SU));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack2_NS_SU));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack2_NS_SU));
        
        
        //kurirNS dohvata prvi paket
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack3_NS_BG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack3_NS_BG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack3_NS_BG));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack3_NS_BG));
        
        
        //kurirSU dohvata prvi paket
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack3_SU_SU));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameSU));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack3_SU_SU));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameSU).contains(pack3_SU_SU));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameSU).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack3_SU_SU));
        
        
        //kurirBG dohvata drugi paket
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack2_BG_NS));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack2_BG_NS));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack2_BG_NS));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack2_BG_NS));
        
        
        //kurirBG dohvata treci paket
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack3_BG_NS));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack3_BG_NS));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack3_BG_NS));
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack3_BG_NS));
        
        
        //kurirBG dohvata cetvrti paket
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack4_BG_SU));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack4_BG_SU));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack4_BG_SU));
        Assert.assertEquals(4L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack4_BG_SU));
        
        
        //kurirSU dohvata drugi paket
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack4_SU_KG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameSU));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack4_SU_KG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameSU).contains(pack4_SU_KG));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameSU).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack4_SU_KG));
        
        
        
        //kurirNS isporucuje prvi paket u bg
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack3_NS_BG));
        Assert.assertEquals(pack3_NS_BG, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack3_NS_BG));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack3_NS_BG));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack3_NS_BG));
        
        
        //kurirNS dohvata paket iz bg za magacin
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack6_BG_KG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack6_BG_KG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack6_BG_KG));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack6_BG_KG));
        
        
        //kurirBG dohvata peti paket
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack5_BG_SU));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack5_BG_SU));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack5_BG_SU));
        Assert.assertEquals(5L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack5_BG_SU));
        
        
        //kurirBG isporucuje prvi paket u bg
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack1_BG_BG));
        Assert.assertEquals(pack1_BG_BG, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack1_BG_BG));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack1_BG_BG));
        Assert.assertEquals(4L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack1_BG_BG));
        
        
        //kurirNS isporucuje drugi paket u su
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack2_NS_SU));
        Assert.assertEquals(pack2_NS_SU, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack2_NS_SU));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack2_NS_SU));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack2_NS_SU));
        
        
        //kurirNS dohvata prvi paket iz su za magacin
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack1_SU_KG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack1_SU_KG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack1_SU_KG));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack1_SU_KG));
        
        
        //kurirSU dohvata treci paket
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack5_SU_SU));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameSU));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack5_SU_SU));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameSU).contains(pack5_SU_SU));
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameSU).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack5_SU_SU));
        
        
        //kurirNS dohvata drugi paket iz su za magacin
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack2_SU_BG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack2_SU_BG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack2_SU_BG));
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack2_SU_BG));
        
        
        //kurirBG isporucuje drugi paket u ns
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack2_BG_NS));
        Assert.assertEquals(pack2_BG_NS, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack2_BG_NS));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack2_BG_NS));
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack2_BG_NS));
        
        
        //kurirSU isporucuje prvi paket u su
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack3_SU_SU));
        Assert.assertEquals(pack3_SU_SU, this.driveOperation.nextStop(courierUsernameSU));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack3_SU_SU));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameSU).contains(pack3_SU_SU));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameSU).size());
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack3_SU_SU));
        
        
        //kurirBG dohvata novi paket iz ns
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack1_NS_KG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(2L, this.packageOperations.getDeliveryStatus(pack1_NS_KG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack1_NS_KG));
        Assert.assertEquals(4L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack1_NS_KG));
        
        
        //kurirBG isporucuje treci paket u ns
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack3_BG_NS));
        Assert.assertEquals(pack3_BG_NS, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack3_BG_NS));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack3_BG_NS));
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack3_BG_NS));
        
        
        //kurirNS se vraca u magacin
        Assert.assertEquals(-1L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(2L, this.courierOperation.getCouriersWithStatus(1).size());
        Assert.assertEquals(0L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack6_BG_KG));
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack1_SU_KG));
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack2_SU_BG));
        Assert.assertTrue(this.courierOperation.getCouriersWithStatus(0).contains(courierUsernameNS));
        BigDecimal profitNS1 = BigDecimal.valueOf(1889017).subtract(BigDecimal.valueOf(361.69).multiply(BigDecimal.valueOf(6.3).multiply(BigDecimal.valueOf(36))));
        
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(2).compareTo(profitNS1.multiply(BigDecimal.valueOf(1.05))) < 0);
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(2).compareTo(profitNS1.multiply(BigDecimal.valueOf(0.95))) > 0);
        
        
        //kurirSU isporucuje drugi paket u su
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack5_SU_SU));
        Assert.assertEquals(pack5_SU_SU, this.driveOperation.nextStop(courierUsernameSU));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack5_SU_SU));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameSU).contains(pack5_SU_SU));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameSU).size());
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack5_SU_SU));
        
        
        //kurirBG isporucuje cetvrti paket u su
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack4_BG_SU));
        Assert.assertEquals(pack4_BG_SU, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack4_BG_SU));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack4_BG_SU));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack4_BG_SU));
        
        
        //kurirSU isporucuje treci paket u kg
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack4_SU_KG));
        Assert.assertEquals(pack4_SU_KG, this.driveOperation.nextStop(courierUsernameSU));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack4_SU_KG));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameSU).contains(pack4_SU_KG));
        Assert.assertEquals(0L, this.driveOperation.getPackagesInVehicle(courierUsernameSU).size());
        Assert.assertEquals(KG, this.packageOperations.getCurrentLocationOfPackage(pack4_SU_KG));
        
                
        //kurirBG isporucuje peti paket u su
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack5_BG_SU));
        Assert.assertEquals(pack5_BG_SU, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack5_BG_SU));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameBG).contains(pack5_BG_SU));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(SU, this.packageOperations.getCurrentLocationOfPackage(pack5_BG_SU));
        
        
        //kurirBG se vraca u magacin
        Assert.assertEquals(-1L, this.driveOperation.nextStop(courierUsernameBG));
        Assert.assertEquals(1L, this.courierOperation.getCouriersWithStatus(1).size());
        Assert.assertEquals(0L, this.driveOperation.getPackagesInVehicle(courierUsernameBG).size());
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack1_NS_KG));
        Assert.assertTrue(this.courierOperation.getCouriersWithStatus(0).contains(courierUsernameBG));
        BigDecimal profitBG1 = BigDecimal.valueOf(1795211).subtract(BigDecimal.valueOf(405.3).multiply(BigDecimal.valueOf(6.3).multiply(BigDecimal.valueOf(36))));
        
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(5).compareTo(profitBG1.multiply(BigDecimal.valueOf(1.05))) < 0);
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(5).compareTo(profitBG1.multiply(BigDecimal.valueOf(0.95))) > 0);
        
        
        //kurirBG planira
        this.driveOperation.planingDrive(courierUsernameNS);
        Assert.assertEquals(2L, this.courierOperation.getCouriersWithStatus(1).size());
     
        
        //kurirSU se vraca u magacin
        Assert.assertEquals(-1L, this.driveOperation.nextStop(courierUsernameSU));
        Assert.assertEquals(1L, this.courierOperation.getCouriersWithStatus(1).size());
        Assert.assertEquals(0L, this.driveOperation.getPackagesInVehicle(courierUsernameSU).size());
        Assert.assertEquals(2L, this.packageOperations.getAllUndeliveredPackagesFromCity(SU).size());
        Assert.assertTrue(this.courierOperation.getCouriersWithStatus(0).contains(courierUsernameSU));
        BigDecimal profitSU1 = BigDecimal.valueOf(1250613).subtract(BigDecimal.valueOf(459.53).multiply(BigDecimal.valueOf(7.3).multiply(BigDecimal.valueOf(32))));
        
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(3).compareTo(profitSU1.multiply(BigDecimal.valueOf(1.05))) < 0);
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(3).compareTo(profitSU1.multiply(BigDecimal.valueOf(0.95))) > 0);
 
        
        //kurirNS dohvata pakete iz magacina
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack6_BG_KG));
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack1_SU_KG));
        Assert.assertEquals(NS, this.packageOperations.getCurrentLocationOfPackage(pack2_SU_BG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack6_BG_KG));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack1_SU_KG));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack2_SU_BG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack6_BG_KG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack1_SU_KG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack2_SU_BG));
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        
        
        //kurirNS isporucuje prvi paket u bg
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack2_SU_BG));
        Assert.assertEquals(pack2_SU_BG, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack2_SU_BG));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack2_SU_BG));
        Assert.assertEquals(2L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack2_SU_BG));
        
        
        //kurirNS dohvata pakete iz magacina u bg
        Assert.assertEquals(BG, this.packageOperations.getCurrentLocationOfPackage(pack1_NS_KG));
        Assert.assertEquals(-2L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack1_NS_KG));
        Assert.assertTrue(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack1_NS_KG));
        Assert.assertEquals(3L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(-1, this.packageOperations.getCurrentLocationOfPackage(pack1_NS_KG));
        
        
        //kurirNS isporucuje drugi i treci paket u kg
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack1_SU_KG));
        Assert.assertEquals(-1L, this.packageOperations.getCurrentLocationOfPackage(pack6_BG_KG));
        int firstDeliveredPack = this.driveOperation.nextStop(courierUsernameNS);
        Assert.assertTrue((firstDeliveredPack == pack1_SU_KG) || (firstDeliveredPack == pack6_BG_KG));
        int secondDeliveredPack = this.driveOperation.nextStop(courierUsernameNS);
        Assert.assertTrue((secondDeliveredPack == pack1_SU_KG) || (secondDeliveredPack == pack6_BG_KG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack1_SU_KG));
        Assert.assertEquals(3L, this.packageOperations.getDeliveryStatus(pack6_BG_KG));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack1_SU_KG));
        Assert.assertFalse(this.driveOperation.getPackagesInVehicle(courierUsernameNS).contains(pack6_BG_KG));
        Assert.assertEquals(1L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(KG, this.packageOperations.getCurrentLocationOfPackage(pack1_SU_KG));
        Assert.assertEquals(KG, this.packageOperations.getCurrentLocationOfPackage(pack6_BG_KG));
        
        
        //kurirNS se vraca u magacin
        Assert.assertEquals(-1L, this.driveOperation.nextStop(courierUsernameNS));
        Assert.assertEquals(0L, this.courierOperation.getCouriersWithStatus(1).size());
        Assert.assertEquals(0L, this.driveOperation.getPackagesInVehicle(courierUsernameNS).size());
        Assert.assertEquals(1L, this.packageOperations.getAllUndeliveredPackagesFromCity(NS).size());
        Assert.assertEquals(0L, this.packageOperations.getAllUndeliveredPackagesFromCity(BG).size());
        Assert.assertEquals(0L, this.packageOperations.getAllUndeliveredPackagesFromCity(SU).size());
        Assert.assertEquals(0L, this.packageOperations.getAllUndeliveredPackagesFromCity(KG).size());
        Assert.assertTrue(this.courierOperation.getCouriersWithStatus(0).contains(courierUsernameNS));
        BigDecimal profitNS2 = BigDecimal.valueOf(1666406).subtract(BigDecimal.valueOf(325.11).multiply(BigDecimal.valueOf(6.3).multiply(BigDecimal.valueOf(36))));
        
        BigDecimal avgWithFiveDel = profitNS1.add(profitNS2).add(profitBG1);
        System.out.println(avgWithFiveDel);
        avgWithFiveDel = avgWithFiveDel.divide(BigDecimal.valueOf(2.0), 3, RoundingMode.HALF_DOWN);
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(5).compareTo(avgWithFiveDel.multiply(BigDecimal.valueOf(1.05))) < 0);
        Assert.assertTrue(this.courierOperation.getAverageCourierProfit(5).compareTo(avgWithFiveDel.multiply(BigDecimal.valueOf(0.95))) > 0);
        
    }
}